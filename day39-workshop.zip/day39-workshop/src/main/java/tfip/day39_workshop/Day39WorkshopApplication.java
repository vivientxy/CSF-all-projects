package tfip.day39_workshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day39WorkshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day39WorkshopApplication.class, args);
	}

}
